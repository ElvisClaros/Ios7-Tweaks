//
//  MediaPlayer.h
//  MediaPlayer
//
//  Copyright 2008 Apple, Inc. All rights reserved.
//

#import <MediaPlayer/MediaPlayerDefines.h>
#import <MediaPlayer/MPMoviePlayerController.h>
#import <MediaPlayer/MPVolumeSettings.h>
#import <MediaPlayer/MPVolumeView.h>
